<?php
    $conn = mysqli_connect("localhost", "root", "") or die("cannot connect"); 
    $mydb=mysqli_select_db($conn, "aps") or die("cannot select DB");
    if($mydb)
    {
	   // echo "<script>alert('Database Connecting Successfully...')</script>"; 
    }
?>

